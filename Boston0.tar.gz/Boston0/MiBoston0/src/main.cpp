/*
 * Metodología de la Programación: Boston0
 * Curso 2024/2025
 */

/** 
 * @file   main.cpp
 * @author estudiante1: apellidos*, nombre*
 * @author estudiante2: apellidos*, nombre* (solo si procede)  
 */

#include <string>
#include <iostream>

#include "Coordinates.h"
#include "DateTime.h"
#include "Crime.h"

using namespace std;

/**
 * The purpose of this program is to read a set of data on crimes committed 
 * in the city of Boston, showing those that have occurred within certain 
 * geographic coordinates and within the date range provided to the program.
 * This program first reads from the standard input two Coordinates objects, one 
 * Coordinates to define the minimun coordinates and another Coordinates to 
 * define the maximum coordinates.
 * Then it reads two DateTime objects, one DateTime to define the minimun 
 * DateTime and another DateTime to define the maximum DateTime.
 * Next it reads an integer number n to define the number of Crime objects to
 * read.
 * Thereafter, it reads n Crime objects, saving in an array of Crimes only the 
 * Crimes whose DateTime is between the minimum and maximun DateTimes and whose 
 * coordinates are valid (@see Coordinates::isValid() method description).
 * Each Crime object is normalized when inserted into the array.
 * Be careful that the number of crimes inserted in the array does not exceed 
 * its capacity.
 * Finally, the program shows in the standard output all the Crimes in the array
 * and then all the Crimes which Coordinates are inside the area defined by
 * the minimum and maximum Coordinates provided to the program. 
 * Be careful to show the output as in the below example.
 *  
 * Running example:
 * > dist/Debug/GNU-Linux/boston0 < data/input00.b0in 
Total number of crimes inserted in the array: 4
0,225520077,3126,UNKNOWN,WARRANT ARREST - OUTSIDE OF BOSTON WARRANT,,,0,2022-02-02 00:00:00,WASHINGTON ST,42.343082,-71.141724
1,222648862,3831,UNKNOWN,M/V - LEAVING SCENE - PROPERTY DAMAGE,B2,288,0, * ,WASHINGTON ST,42.329750,-71.084541
4,222111641,619,UNKNOWN,LARCENY ALL OTHERS,D14,778,0,2022-02-14 12:30:00,WASHINGTON ST,42.349056,-71.150497
5,222107076,3126,UNKNOWN,WARRANT ARREST - OUTSIDE OF BOSTON WARRANT,D4,UNKNOWN,0,2022-03-11 10:45:00,MASSACHUSETTS AVE & ALBANY ST BOSTON  MA 02118 UNI,42.333500,-71.073509

Crimes within the given geographic area:
0,225520077,3126,UNKNOWN,WARRANT ARREST - OUTSIDE OF BOSTON WARRANT,,,0,2022-02-02 00:00:00,WASHINGTON ST,42.343082,-71.141724
4,222111641,619,UNKNOWN,LARCENY ALL OTHERS,D14,778,0,2022-02-14 12:30:00,WASHINGTON ST,42.349056,-71.150497
5,222107076,3126,UNKNOWN,WARRANT ARREST - OUTSIDE OF BOSTON WARRANT,D4,UNKNOWN,0,2022-03-11 10:45:00,MASSACHUSETTS AVE & ALBANY ST BOSTON  MA 02118 UNI,42.333500,-71.073509
 */

int main(int argc, char* argv[]) {
    const int DIM_ARRAY = 10; // dimension of the array arrayCrimes
    Crime arrayCrimes[DIM_ARRAY]; // array of Crimes
    int arrayCrimes_util = 0;
 
    // Read latitude and longitude for 2 Coordinates objects
    float esq_sup_dcha_lat;
    cin >> esq_sup_dcha_lat;
    
    float esq_sup_dcha_long;
    cin >> esq_sup_dcha_long;
    
    Coordinates esq_sup_dcha(esq_sup_dcha_lat, esq_sup_dcha_long);
    
    float esq_inf_izda_lat;
    cin >> esq_inf_izda_lat;
    
    
    float esq_inf_izda_long;
    cin >> esq_inf_izda_long;
    
    Coordinates esq_inf_izda(esq_inf_izda_lat, esq_inf_izda_long);
    
    // Remember to take off the \n character after longitude of max Coordinates
    char c[1];
    cin.getline(c, 1);
    
    // Read 2 DateTime objects
    char f_inicial[300];
    cin.getline(f_inicial, 300);
    string f_inicial_string = (string)f_inicial;
    DateTime fecha_inicial(f_inicial);
    
    char f_final[300];
    cin.getline(f_final, 300);
    string f_final_string = (string)f_final;
    DateTime fecha_final(f_final);

    // Read the number of crimes
    int n_crimes;
    cin >> n_crimes;
    // Remember to take off the \n character after number of crimes 
    cin.getline(c, 1);
    
    // Read the Crimes and put them in the array arrayCrimes
    //    whenever they follow the required restrictions and 
    //    once normalized
    
    for (int i = 0; i < n_crimes; i++) {
        char c_actual[10000];
        cin.getline(c_actual, 10000);
        string c_actual_string = (string)c_actual;
        Crime crimen_actual(c_actual_string);
        
        Coordinates coords = crimen_actual.getLocation();
        
        cout << endl << coords.toString() << endl;
        
        DateTime date = crimen_actual.getDateTime();
        if (coords.isValid() && date >= fecha_inicial && date <= fecha_final) {
            Normalize(crimen_actual);
            
            arrayCrimes[arrayCrimes_util] = crimen_actual;
            arrayCrimes_util++;
        }
    }
    
    cout << "Total number of crimes inserted in the array: " << arrayCrimes_util + 1 << endl;
    // display the number and the current content for the arrayCrimes
    for (int i = 0; i < arrayCrimes_util; i++) {
        cout << arrayCrimes[i].toString() << endl;
    }
  
    cout << "\nCrimes within the given geographic area:" << endl;
    // display all the Crimes in the array which Coordinates are inside the given area
    for (int i = 0; i < arrayCrimes_util; i++) {
        if (arrayCrimes[i].getLocation().isInsideArea(esq_inf_izda, esq_sup_dcha)) {
            cout << arrayCrimes[i].toString() << endl;
        }
    }
}